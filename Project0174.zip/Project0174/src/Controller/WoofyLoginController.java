package Controller;

import Modle.UserModel;
import View.woofy_login;
import View.Menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class WoofyLoginController {

    private UserModel model;
    private woofy_login view;

    public WoofyLoginController(UserModel model, woofy_login view) {
        this.model = model;
        this.view = view;

        this.view.setLoginButtonListener(new LoginButtonListener());
    }

    public boolean authenticate(String username, String password) {
        return model.authenticateUser(username, password);
    }

    public class LoginButtonListener implements ActionListener { // Made public
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = view.getUsername();
            String password = view.getPassword();

            // Delegate authentication to UserModel
            boolean authenticated = authenticate(username, password);

            if (authenticated) {
                Menu menu = new Menu();  // Assuming Menu class is correctly defined
                menu.setVisible(true);
                view.dispose();
                JOptionPane.showMessageDialog(null, "Login Successful!");
            } else {
                JOptionPane.showMessageDialog(null, "User Name or Password Incorrect..!");
            }
        }
    }

    public static void main(String[] args) {
        UserModel model = new UserModel();
        woofy_login view = new woofy_login();
        new WoofyLoginController(model, view);
        view.setVisible(true);
    }
}
