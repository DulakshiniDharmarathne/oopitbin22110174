package Modle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class UserModel {

    Connection conn;

    public UserModel() {
        conn = DBconnect.connect(); // Assuming DBconnect is a class handling database connection
    }

    public boolean authenticateUser(String username, String password) {
        try {
            String query = "SELECT * FROM wreg WHERE fname = ? AND lname = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true; // User authenticated successfully
            } else {
                return false; // Authentication failed
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e); // Handle exceptions
            return false;
        }
    }
}
